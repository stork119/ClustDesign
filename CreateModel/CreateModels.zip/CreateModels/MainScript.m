% model name
clear all
name='minimal';
%createJAKSTAT_GB_MRE(name);
%%loading model
addpath([pwd,'/models/','/',name,'/symbolic/']);
addpath([pwd, '/models','/',name]);
[parn, parv, parnames] = textread([pwd, '/models/','/',name,'/'  ,name, '.par'], '%s %f %q');
stoichiometry=load([pwd, '/models/','/',name,'/' ,name,'_stoich.txt']);
%SC = 10;
%SCvector = [SC,SC, 1, SC, SC, 1, 1, 1, SC, SC , 1, 1]',
%parv = parv./SCvector

%%initial conditions
y0=zeros(1,4);


%%initial conditions

N=120; % number of observations
freq=0.1; % time distance between observations
init_T=0.0; % initial time
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%initial condition;
size_sto=size(stoichiometry); nvar=size_sto(1); 
par=parv; npar=length(parn);
all_equations=str2func([name,'_MRE']); x = linspace(init_T,init_T+freq*N,N); 
tspan=[0,init_T+freq*N];
mysolution=ode15s(all_equations,tspan,y0,[],parv);
traj=deval(mysolution,x);


subplot(4,1,1);
plot(x,traj(1,:)); % total stat
subplot(4,1,2);
plot(x,traj(2,:)); % total stat
subplot(4,1,3);
plot(x,traj(3,:)); % total stat
subplot(4,1,4);
plot(x,traj(4,:)); % total stat


