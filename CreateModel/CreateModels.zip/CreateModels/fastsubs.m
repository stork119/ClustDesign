

[parn, parv, parnames] = textread([pwd,'/' ,'gene', '.par'], '%s %f %q');

par=parv;

par=parv;




y0(1)=par(1)/par(3);
y0(2)=par(1)*par(2)/(par(3)*par(4));
y0(3)=y0(1);
y0(4)=y0(2)*(1+ par(2)/(par(3)+par(4)));
y0(5)=par(1)*par(2)/(par(3)*(par(3)+par(4)));



%%%%%%%%%% 1

par(1)=100;
par(2)=1;
par(3)=1.2;
par(4)=0.7;



y0(1)=par(1)/par(3);
y0(2)=par(1)*par(2)/(par(3)*par(4));
y0(3)=y0(1);
y0(4)=y0(2)*(1+ par(2)/(par(3)+par(4)));
y0(5)=par(1)*par(2)/(par(3)*(par(3)+par(4)));


NN=40;

dets1=zeros(NN,1);
sdg1=zeros(NN,1);


for i=1:NN,
W=FisherFunction('gene',2,10,i*0.05,10,y0,[2],par);
%W=W([1, 3], [1,3]);
dets1(i)=det(W);
sdg1(i)=sum(diag(W));
end


ts=0.05*(1:NN);
figure
plot(ts,dets1);




%%%%%%%%%% 2
par(1)=10;
par(2)=20;
par(3)=0.5;
par(4)=1;




y0(1)=par(1)/par(3);
y0(2)=par(1)*par(2)/(par(3)*par(4));
y0(3)=y0(1);
y0(4)=y0(2)*(1+ par(2)/(par(3)+par(4)));
y0(5)=par(1)*par(2)/(par(3)*(par(3)+par(4)));


NN=80;

dets2=zeros(NN,1);
sdg2=zeros(NN,1);

for i=1:NN,
W=FisherFunction('gene',2,10,i*0.025,10,y0,[2],par);
%W=W([1, 3], [1,3]);
dets2(i)=det(W);
sdg2(i)=sum(diag(W));
end


ts=0.025*(1:NN);
figure
plot(ts,dets2);




%%%%%%%%%% 3
par(1)=50;
par(2)=10;
par(3)=0.5;
par(4)=1;




y0(1)=par(1)/par(3);
y0(2)=par(1)*par(2)/(par(3)*par(4));
y0(3)=y0(1);
y0(4)=y0(2)*(1+ par(2)/(par(3)+par(4)));
y0(5)=par(1)*par(2)/(par(3)*(par(3)+par(4)));

NN=80;

dets3=zeros(NN,1);
sdg3=zeros(NN,1);
for i=1:NN,
W=FisherFunction('gene',2,10,i*0.025,10,y0,[2],par);
%W=W([1, 3], [1,3]);
dets3(i)=det(W);
sdg3(i)=sum(diag(W));
end


ts=0.025*(1:NN);
figure
plot(ts,dets3);




%%%%%%%%%% 4
par(1)=50;
par(2)=10;
par(3)=1;
par(4)=0.5;




y0(1)=par(1)/par(3);
y0(2)=par(1)*par(2)/(par(3)*par(4));
y0(3)=y0(1);
y0(4)=y0(2)*(1+ par(2)/(par(3)+par(4)));
y0(5)=par(1)*par(2)/(par(3)*(par(3)+par(4)));


NN=80;

dets4=zeros(NN,1);
sdg4=zeros(NN,1);
for i=1:NN,
W=FisherFunction('gene',2,10,i*0.025,10,y0,[2],par);
%W=W([1, 3], [1,3]);
dets4(i)=det(W);
sdg4(i)=sum(diag(W));
end


ts=0.025*(1:NN);
figure
plot(ts,dets4);


figure
hand=plot(ts, [dets1,dets2,dets3, dets4]);

set(hand, 'LineWidth', 2);

legend('set 1','set 2','set 3', 'set 4')
 
xlabel('\Delta') 
ylabel('det( FIM )')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


par(1)=50;
par(2)=10;
par(3)=1;
par(4)=0.5;



y0(1)=par(1)/par(3);
y0(2)=par(1)*par(2)/(par(3)*par(4));
y0(3)=y0(1);
y0(4)=y0(2)*(1+ par(2)/(par(3)+par(4)));
y0(5)=par(1)*par(2)/(par(3)*(par(3)+par(4)));


% FisherFunction(name,nvar,N,freq, init_T,y0,obs,par)
i=11
W1=FisherFunction('gene',2,20,i*0.05,10,y0,[2],par);
W1DTR=FisherFunctionDTR('gene',2,20,i*0.05,10,y0,[2],100,par);
W1TP=FisherFunctionTiPo('gene',2,20,i*0.05,10,y0,[2],par);


Q=diag(W1)
E=eig(W1)


QDTR=diag(W1DTR)
EDTR=eig(W1DTR)

QTP=diag(W1TP)
ETP=eig(W1TP)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%% Section idetifiability analysis and perturbation  experiment%%%%%%%
y0_pert=y0
y0_pert(1:2)=y0(1:2)*5
y0_pert(3:5)=y0(3:5)*25

 plottraj('gene',2,10,i*0.05,10,y0_pert,[2])

i=11
W1_P=FisherFunction('gene',2,10,i*0.05,2,y0_pert,[2],par);
W1DTR_P=FisherFunctionDTR('gene',2,10,i*0.05,2,y0_pert,[2],100,par);
W1TP_P=FisherFunctionTiPo('gene',2,10,i*0.05,2,y0_pert,[2],par);


Q_P=diag(W1_P)
E_P=eig(W1_P)


QDTR_P=diag(W1DTR_P)
EDTR_P=eig(W1DTR_P)

QTP_P=diag(W1TP_P)
ETP_P=eig(W1TP_P)



trace(inv(W1))

trace(inv(W1TP))

trace(inv(W1DTR))






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






par(1)=10;
par(2)=20;
par(3)=1;
par(4)=0.5;

i=11
W1=FisherFunction('gene',2,10,i*0.05,10,y0,[2],par);



figure

kk=1
for i=1:4,
for j=1:4,

subplot(4,4,kk)
plotFM(2,2,W1([i j],[i j]),100)
xlabel(parn(i))
ylabel(parn(j))

kk=kk+1;
end
end


par(1)=10;
par(2)=20;
par(3)=1;
par(4)=0.5;

i=7
W2=FisherFunction('gene',2,10,i*0.05,10,y0,[2],par);

figure

kk=1
for i=1:4,
for j=1:4,

subplot(4,4,kk)
plotFM(2,2,W2([i j],[i j]),100)
xlabel(parn(i))
ylabel(parn(j))

kk=kk+1;
end
end


figure

kk=1
for i=1:4,
for j=1:4,

subplot(4,4,kk)
plotdFM(2,2,W1([i j],[i j]),W2([i j],[i j]),100)
xlabel(parn(i))
ylabel(parn(j))
kk=kk+1;
end
end

legend('Set 1','Set 3');

suptitle('Differences TP-TS')















suptitle('Deterministic')


figure

kk=1
for i=1:7,
for j=1:7,

subplot(7,7,kk)
plotFM(10,10,FM([i j],[i j]),100)
xlabel(parn(i))
ylabel(parn(j))
kk=kk+1;
end
end


suptitle('Stochastic timeseries')




figure

kk=1
for i=1:7,
for j=1:7,

subplot(7,7,kk)
plotFM(10,10,FMTP([i j],[i j]),100)
xlabel(parn(i))
ylabel(parn(j))
kk=kk+1;
end
end

suptitle('Stochastic timepoints')



figure

kk=1
for i=1:7,
for j=1:7,

subplot(7,7,kk)
plotdFM(10,10,FMTP([i j],[i j]),FM([i j],[i j]),100)
xlabel(parn(i))
ylabel(parn(j))
kk=kk+1;
end
end

suptitle('Differences TP-TS')





figure

kk=1
for i=1:7,
for j=1:7,

subplot(7,7,kk)
plotdFM(10,10,FMDT([i j],[i j]),FM([i j],[i j]),100)
xlabel(parn(i))
ylabel(parn(j))
kk=kk+1;
end
end

suptitle('Differences DT-TS')








[A B C]=svd(FM);


[ATP BTP CTP]=svd(FMTP);


[ADT BDT CDT]=svd(FMDT);

% 
% figure
% 
% subplot(1,3,1)
% plot(log(diag(B)))
% 
% 
% subplot(1,3,2)
% plot(log(diag(BTP)))
% 
% 
% subplot(1,3,3)
% plot(log(diag(BDT)))
% 
% 
% 
% 
% 
% 
% figure
% 
% subplot(1,3,1)
% plot((diag(B)))
% 
% 
% subplot(1,3,2)
% plot((diag(BTP)))
% 
% 
% subplot(1,3,3)
% plot((diag(BDT)))



EGMA=[diag(B),diag(BTP),diag(BDT)];

EGMAN=EGMA;

EGMAN(:,1)=EGMA(:,1)/max(EGMA(:,1));

EGMAN(:,2)=EGMA(:,2)/max(EGMA(:,2));

EGMAN(:,3)=EGMA(:,3)/max(EGMA(:,3));

figure
subplot(2,1,1)
plot(EGMAN)
legend('TS','TP','DT')
title('Eigen values normalized against model maximum')



EGMA=[diag(B),diag(BTP),diag(BDT)]; 

EGMAN1=EGMA/max(max(EGMA));

subplot(2,1,2)
plot(EGMAN1)
legend('TS','TP','DT')
title('Eigen values normalized against total maximum')





figure
plottraj('gene',3,60,0.2,10,y0,[1,2,3])
legend('x','y_0','y')
title('Deterministic trajectories')






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% END of p53 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






[parn, parv, parnames] = textread([pwd,'/' ,'gene', '.par'], '%s %f %q');

par=parv;




y0(1)=par(1)/par(3);
y0(2)=par(1)*par(2)/(par(3)*par(4));
y0(3)=y0(1);
y0(4)=y0(2)*(1+ par(2)/(par(3)+par(4)));
y0(5)=par(1)*par(2)/(par(3)*(par(3)+par(4)));


NN=20;

dets=zeros(NN,1);
eigs=zeros(NN,1);

for i=1:NN,
W=FisherFunctionTiPo('gene',2,10,i*0.05,10,y0,[1]);
W=W([1, 3], [1,3]);
dets(i)=det(W);
[A B C]=svd(W);
eigs(i)=B(1);
end


ts=0.1*(1:NN);
plot(ts,eigs);







%%%%%%%%%%%%%%%%%%%%%%
%   20.0000
%   10.0000
%    2.0000
%    0.5000




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% RNA -- half-life 0.34

NN=20;

dets=zeros(NN,1);

for i=1:NN,
W=FisherFunction('gene',2,10,i*0.05,10,y0,[1]);
W=W([1, 3], [1,3]);
dets(i)=det(W);
end


ts=0.1*(1:NN);
plot(ts,dets);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%     Protein -- half-life 1.3 


NN=40;

dets=zeros(NN,1);

for i=1:NN,
W=FisherFunction('gene',2,10,i*0.05,10,y0,[2]);
%W=W([1, 3], [1,3]);
dets(i)=det(W);
end


ts=0.05*(1:NN);
figure
plot(ts,dets);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Independent Sampling
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%% RNA

NN=20;

dets=zeros(NN,1);
eigs=zeros(NN,1);

for i=1:NN,
W=FisherFunctionTiPo('gene',2,10,i*0.05,10,y0,[1]);
W=W([1, 3], [1,3]);
dets(i)=det(W);
[A B C]=svd(W);
eigs(i)=B(1);
end


ts=0.1*(1:NN);
plot(ts,eigs);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% PROTEIN

NN=40;

dets=zeros(NN,1);
eigs=zeros(NN,2);

for i=1:NN,
W=FisherFunctionTiPo('gene',2,10,i*0.05,10,y0,[2]);
%W=W([1, 3], [1,3]);
dets(i)=det(W);

[A B C]=svd(W);
eigs(i,1)=B(1,1);
eigs(i,2)=B(2,2);
eigs(i,3)=B(3,3);
eigs(i,4)=B(4,4);
end


ts=0.2*(1:NN);
plot(ts,dets);







