function [ output_args ] = create(name)
% require

%% reading the model definition files 
disp('reading the model definition files') 
DefsDir = [pwd, '/models/', name];  %where model definition files are found
[parn, parv, parnames] = textread([pwd, '/models/','/',name,'/'  ,name, '.par'], '%s %f %q'); %reading in information about parameters
stoichiometry=load([pwd, '/models/','/',name,'/' ,name,'_stoich.txt']); %reading stoichiometry matrix
mkdir([pwd,'/models/','/',name,'/symbolic/']); %creating a folder for results of symbolic computations 
addpath([pwd,'/models/','/',name,'/symbolic/']); % adding paths to the model
addpath([pwd, '/models','/',name]);

size_sto=size(stoichiometry); %dimension of stoichiomety matrix
varn=size_sto(1);
rean=size_sto(2);

%%symbolic definition of stoichiometry matrix
syms S;
for i=1:size_sto(1),
    for j=1:size_sto(2),
    S(i,j)=stoichiometry(i,j);
    end
    
end

%%symbolic definition of the state vector
disp('creating definition of the model');
y=sym('y','positive');
% create names of variables


for i=1:varn,   
     y(i) = sym((['y',num2str(i)]),'positive');
     var_st{i}=['y(',num2str(i),')'];
     var_st_sym{i}=['y',num2str(i)];
end


%%symbolic definition of parameter vector
param=sym('param','positive' );
t=sym('t','positive' );
stim=sym('stim','positive' );

pnum = length(parn);
for i = 1:pnum,
    param(i) = sym(['p',num2str(i)],'positive'); 
     par_st{i}=['p(',num2str(i),')'];
     par_st_sym{i}=['p',num2str(i)];
end
rates = str2func([name,'_rates']);

%% creating  symbolic macroscopic rate equation (MRE)
disp('creating macroscopic rate equation')
symrates=feval(rates,y,param,t,stim);
MRE=S*symrates;

%% creating symbolic Jacobian of MRE
 disp('creating Jacobian of MRE')
 
 J=jacobian(MRE,y(1:varn));
 J_pom=substitution(J,var_st_sym,var_st);
 savefunction(substitution(J_pom,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_MRE_jacobian.m']);


%% creating symbolic variance equations
disp('creating variance equations')
E=sym('E','positive');
for j=1:rean,
E(j,j)=(sqrt(symrates(j)));        
end
EE=sym('EE','positive');
for j=1:rean,
EE(j,j)=((symrates(j)));        
end
D=sym('D','real');
D=(S*EE)*(S');
Sigma=sym('Sigma','real');

totdim=2*varn+varn*(varn-1)/2;

y(totdim)=0;

% giving names to symbolic variables
k=1;
for i=1:varn,
for j=(i+1):varn,
     y(varn+varn+k) = sym(['y',num2str(varn+varn+k)],'real');
     var_st{varn+varn+k}=['y(',num2str(varn+varn+k),')'];
     var_st_sym{varn+varn+k}=['y',num2str(varn+varn+k)];

 k=k+1;   
end
end


for i=1:varn,
  y(varn+i) = sym(['y',num2str(varn+i)],'real');
     var_st{varn+i}=['y(',num2str(varn+i),')'];
     var_st_sym{varn+i}=['y',num2str(varn+i)];
end

% assigning names to symbolic matrix Sigma
for i=1:varn,%diagonal elements
  Sigma(i,i)=y(varn+i);
end


%%% lower diagonal
k=1;
for i=1:varn,
for j=(i+1):varn,
   Sigma(i,j)=y(varn+varn+k);
 k=k+1;   
end
end
%using symmetry
Sigma=Sigma+Sigma';

%%%diagonal
for i=1:varn,
   Sigma(i,i)=y(varn+i);
end


Sigma_dot=J*Sigma+ Sigma*(J')+D;

% rewriting variance equations from a matrix format to a vector format
sym('variances_dot','real');

k=1;
for i=1:varn,
variances_dot(i)=Sigma_dot(i,i);
k=k+1;
end


for i=1:varn,
for j=(i+1):varn,
  variances_dot(k)=Sigma_dot(i,j);
 k=k+1;   
end
end


%% create concatenated set of equations Y
all_eq=[MRE; variances_dot'];
all_eq_pom=substitution(all_eq,var_st_sym,var_st);


  stm_st{1}='stimulus(t)';
  stm_st_sym{1}='stim';

%all_eq_pom=substitution(all_eq_pom,'p(1)','p1');
all_eq_pom=substitution(all_eq_pom,stm_st_sym,stm_st);

%writting equation as a function
savefunction(substitution(all_eq_pom,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_all_equations.m']);


disp('creating Jacobians')
%% create variable jacobian of Y
J_all_eq_dvar=jacobian(all_eq,y);
J_all_eq_dvar=substitution(J_all_eq_dvar,var_st_sym,var_st);
J_all_eq_dvar=substitution(J_all_eq_dvar,stm_st_sym,stm_st);
%writting equation as a function
savefunction(substitution(J_all_eq_dvar,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_all_equations_jacobian_dvar.m']);

%% create parameter jacobian of Y
J_all_eq_dpar=jacobian(all_eq,param); % variables in raws parameters in colums;each row is differentiated by each parameters subsequently
J_all_eq_dpar=substitution(J_all_eq_dpar,var_st_sym,var_st);
J_all_eq_dpar=substitution(J_all_eq_dpar,stm_st_sym,stm_st);
%writting equation as a function
%writting equation as a function
savefunction(substitution(J_all_eq_dpar,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_all_equations_jacobian_dpar.m']);


%% variable jacobian  of variable jacobian of MRE
J_JMRE_dvar=jacobian(J,y(1:varn));
J_JMRE_dvar=substitution(J_JMRE_dvar,var_st_sym,var_st);
J_JMRE_dvar=substitution(J_JMRE_dvar,stm_st_sym,stm_st);
%writting equation as a function
savefunction(substitution(J_JMRE_dvar,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_jacobianMRE_jacobian_dvar.m']);

%% parameter jacobian  of variable jacobian of MRE
J_JMRE_dpar=jacobian(J,param);
J_JMRE_dpar=substitution(J_JMRE_dpar,var_st_sym,var_st);
J_JMRE_dpar=substitution(J_JMRE_dpar,stm_st_sym,stm_st);
%writting equation as a function
savefunction(substitution(J_JMRE_dpar,par_st_sym,par_st), [pwd, '/models/','/',name,'/symbolic/',name,'_jacobianMRE_jacobian_dpar.m']);

disp('files created')
end

