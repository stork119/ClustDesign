% model name
clear all
name='JAKSTATGB';
%createJAKSTAT_GB_MRE(name);


%%loading model
addpath([pwd,'/models/','/',name,'/symbolic/']);
addpath([pwd, '/models','/',name]);
[parn, parv, parnames] = textread([pwd, '/models/','/',name,'/'  ,name, '.par'], '%s %f %q');
stoichiometry=load([pwd, '/models/','/',name,'/' ,name,'_stoich.txt']);

W_C=6.02*(10^23)*1400*10^(-18)*10^(-6)
% 6.02*(10^23) Avogadro constant
% 1400?m3 cytoplasmic volume 
% 10^(-6) nanomolar (1nM=10^(-6)mol/m3)


%%initial conditions
y0=zeros(1,36);
y0(1)=1.99989483593865340000e+002*W_C; % Cytoplasmic unphosporylated STAT1
y0(15)=1.99989483593865340000e+002*W_C; %  x1+x2 +2�x3'
y0(1+15)=1.99989483593865340000e+002*W_C;  % Cytoplasmic unphosporylated STAT2
y0(15+15)=1.99989483593865340000e+002*W_C; %   x16+x17 +2�x18

y0(31)=parv(22)/parv(19);
y0(34)=parv(29)/parv(26);

%parameter conversion
parv(4)=parv(4)/W_C;
parv(13)=parv(13)/W_C;
parv(30)=10^(-2.15);
parv(31)=10^(-2.35);




size_sto=size(stoichiometry); nvar=size_sto(1); 
par=parv; npar=length(parn);

all_equations=str2func([name,'_MRE']);
tspan=[0,200];

mysolution=ode15s(all_equations,tspan,y0,[],parv);
x=[0,5,10,15,45,60,120,180] %measurement times in minutes
traj=deval(mysolution,x);
    
   close all

figure('Name','Measured variables','NumberTitle','off')

subplot(2,3,1);
hold on
plot(x,traj([1],:)+traj([2],:) +2*(sum(traj([3:13],:),1))+sum(traj([18:28],:),1) );
plot(x,traj([16],:)+traj([17],:) +1*sum(traj([18:28],:),1),'color','red');
hold off
legend('Total S1  ', ' Total S2');

subplot(2,3,2);
hold on
plot(x,traj([2],:) +2*(sum(traj([3:13],:),1))+sum(traj([18:28],:),1) );
plot(x,traj([17],:) +1*sum(traj([18:28],:),1),'color','red');
hold off
legend('Total pS1  ', ' Total pS2');


subplot(2,3,3);
hold on
plot(x,traj([2],:) +2*(sum(traj([3],:),1))+sum(traj([18],:),1) );
plot(x,traj([17],:) +1*sum(traj([18],:),1),'color','red');
hold off
legend('Cyto pS1  ', ' Cyto pS2');


subplot(2,3,4);
hold on
plot(x,traj([1],:)+traj([2],:) +2*(sum(traj([3],:),1)));
plot(x,traj([16],:)+traj([17],:)+1*sum(traj([18],:),1),'color','red');
hold off
legend('Cyto S1  ', ' Cyto S2');



subplot(2,3,5);
hold on
plot(x, 2*(sum(traj([4:13],:),1))+sum(traj([19:28],:),1) );
plot(x,sum(traj([19:28],:),1),'color','red');
hold off
legend('Nuclear  pS1  ', ' nuclear pS2');







