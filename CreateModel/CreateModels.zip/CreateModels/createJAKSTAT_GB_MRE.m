function [ output_args ] = create(name)

name = 'minimal'
%% reading the model definition files 
disp('reading the model definition files') 
DefsDir = [pwd, '/models/', name];  %where model definition files are found
[parn, parv, parnames] = textread([pwd, '/models/','/',name,'/'  ,name, '.par'], '%s %f %q'); %reading in information about parameters
stoichiometry=load([pwd, '/models/','/',name,'/' ,name,'_stoich.txt']); %reading stoichiometry matrix
mkdir([pwd,'/models/','/',name,'/symbolic/']); %creating a folder for results of symbolic computations 
addpath([pwd,'/models/','/',name,'/symbolic/']); % adding paths to the model
addpath([pwd, '/models','/',name]);

size_sto=size(stoichiometry); %dimension of stoichiomety matrix
varn=size_sto(1);
rean=size_sto(2);

%%symbolic definition of stoichiometry matrix

syms S;
for i=1:size_sto(1),
    for j=1:size_sto(2),
    S(i,j)=stoichiometry(i,j);
    end
end


 

%%symbolic definition of the state vector
disp('creating definition of the model');
y=sym('y','positive');
% create names of variables



for i=1:varn,   
     y(i) = sym((['y',num2str(i)]),'positive');
     var_st{i}=['y(',num2str(i),')'];
     var_st_sym{i}=['y',num2str(i)];
     var_st_cpp{i}=['_y[',num2str(i-1),']'];
end



%%symbolic definition of parameter vector
param=sym('param','positive' );
t=sym('t','positive' );





   
  %% stimulants
%    stim(1) = sym(['stim',num2str(1)],'positive'); 
%    stim(2) = sym(['stim',num2str(2)],'positive');  
%    
%   stm_st{1}='stimulus(t)';
%   stm_st_sym{1}='stim1';  
%   stm_st{2}='stimulusG(t,p(33))';
%   stm_st_sym{2}='stim2';

snum = 2;
for i = 1:snum,
     stim(i) = sym(['stm',num2str(i)],'positive'); 
     stm_st{i}=['stimulus',num2str(i),'(t)'];
     stm_st_sym{i}=['stm',num2str(i)];
     stm_st_cpp{i}=['stimulus',num2str(i),'(t)'];
end
  
%    par_st{i}=['p(',num2str(i),')'];
%    par_st_sym{i}=['p',num2str(i)];


%% parameters
pnum = length(parn);
for i = 1:pnum,
     param(i) = sym(['p',num2str(i)],'positive'); 
     par_st{i}=['p(',num2str(i),')'];
     par_st_sym{i}=['p',num2str(i)];
     par_st_cpp{i}=['p[',num2str(i-1),']'];
end


rates = str2func([name,'_rates']);

%% creating  symbolic macroscopic rate equation (MRE)
disp('creating macroscopic rate equation')
symrates=feval(rates,y,param,t,stim);
MRE=S*symrates;

% % giving names to symbolic variables
% k=1;
% for i=1:varn,
% for j=(i+1):varn,
%      y(varn+varn+k) = sym(['y',num2str(varn+varn+k)],'real');
%      var_st{varn+varn+k}=['y(',num2str(varn+varn+k),')'];
%      var_st_cpp{varn+varn+k}=['y[',num2str(varn+varn+k - 1),']'];
%      var_st_sym{varn+varn+k}=['y',num2str(varn+varn+k)];
% 
%  k=k+1;   
% end
% end
% 
% 
% for i=1:varn,
%   y(varn+i) = sym(['y',num2str(varn+i)],'real');
%      var_st{varn+i}=['y(',num2str(varn+i),')'];
%      var_st_sym{varn+i}=['y',num2str(varn+i)];
% end
% 
% % assigning names to symbolic matrix Sigma
% for i=1:varn,%diagonal elements
%   Sigma(i,i)=y(varn+i);
% end
% 
% 
% %%% lower diagonal
% k=1;
% for i=1:varn,
% for j=(i+1):varn,
%    Sigma(i,j)=y(varn+varn+k);
%  k=k+1;   
% end
% end
% %using symmetry
% Sigma=Sigma+Sigma';
% 
% %%%diagonal
% for i=1:varn,
%    Sigma(i,i)=y(varn+i);
% end


%% create concatenated set of MRE equations
MRE_eq=MRE;
MRE_eq_pom=substitution(MRE_eq,var_st_sym,var_st);
MRE_eq_pom=substitution(MRE_eq_pom,stm_st_sym,stm_st);

savefunction(substitution(MRE_eq_pom,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_MRE.m']);

MRE_eq_pom_cpp=substitution(MRE_eq,var_st_sym,var_st_cpp);
MRE_eq_pom_cpp=substitution(MRE_eq_pom_cpp,stm_st_sym,stm_st_cpp);

savefunctioncpp(substitution(MRE_eq_pom_cpp,par_st_sym,par_st_cpp),[pwd, '/models/','/',name,'/symbolic/',name,'_MRE_cpp.m']);


all_eq=MRE;
disp('creating Jacobians')
%% create variable jacobian of Y
J_all_eq_dvar=jacobian(all_eq,y);
J_all_eq_dvar_cpp=substitution(J_all_eq_dvar,var_st_sym,var_st_cpp);
J_all_eq_dvar=substitution(J_all_eq_dvar,var_st_sym,var_st);
J_all_eq_dvar_cpp=substitution(J_all_eq_dvar_cpp,stm_st_sym,stm_st_cpp);
J_all_eq_dvar=substitution(J_all_eq_dvar,stm_st_sym,stm_st);
%writting equation as a function
savefunctioncpp(substitution(J_all_eq_dvar_cpp,par_st_sym,par_st_cpp),[pwd, '/models/','/',name,'/symbolic/',name,'_all_equations_jacobian_dvar_cpp.m']);
savefunction(substitution(J_all_eq_dvar,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_all_equations_jacobian_dvar.m']);

%% create parameter jacobian of Y
J_all_eq_dpar=jacobian(all_eq,param); % variables in raws parameters in colums;each row is differentiated by each parameters subsequently
J_all_eq_dpar=substitution(J_all_eq_dpar,var_st_sym,var_st);
J_all_eq_dpar_cpp=substitution(J_all_eq_dpar,var_st_sym,var_st_cpp);
J_all_eq_dpar=substitution(J_all_eq_dpar,stm_st_sym,stm_st);
J_all_eq_dpar_cpp=substitution(J_all_eq_dpar_cpp,stm_st_sym,stm_st_cpp);
%writting equation as a function
%writting equation as a function
savefunction(substitution(J_all_eq_dpar,par_st_sym,par_st),[pwd, '/models/','/',name,'/symbolic/',name,'_all_equations_jacobian_dpar.m']);
savefunctioncpp(substitution(J_all_eq_dpar_cpp,par_st_sym,par_st_cpp),[pwd, '/models/','/',name,'/symbolic/',name,'_all_equations_jacobian_dpar_cpp.m']);

 

disp('files created')
end

